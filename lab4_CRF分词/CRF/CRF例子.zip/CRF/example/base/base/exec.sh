 ../../crf_learn -t -c 4.0 template train.data model

